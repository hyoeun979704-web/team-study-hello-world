"""
COVID-19 Cumulative Cases by Country with Key Inflection Points
국가별 누적 확진자 추이와 주요 변곡점 시각화

Requirements:
pip install pandas plotly

Author: AI Data Analyst
Date: 2026-02-06
"""

import pandas as pd
import plotly.graph_objects as go
from datetime import datetime

# ============================================================================
# 1. 데이터 로드 및 전처리
# ============================================================================

def load_and_preprocess_data(filepath='WHO-COVID-19-global-daily-data.csv'):
    """
    WHO COVID-19 데이터를 로드하고 월별 집계 수행

    Parameters:
    -----------
    filepath : str
        WHO COVID-19 데이터 파일 경로

    Returns:
    --------
    df_monthly : pd.DataFrame
        월별 집계된 국가별 확진자 데이터
    """
    # 데이터 로드
    df = pd.read_csv(filepath, encoding='utf-8')
    df['Date_reported'] = pd.to_datetime(df['Date_reported'])

    # 분석 대상 국가 정의
    target_countries = [
        'China', 
        'United States of America', 
        'Italy', 
        'Spain', 
        'United Kingdom', 
        'Germany', 
        'France', 
        'India', 
        'Brazil', 
        'Republic of Korea'
    ]

    # 월별 집계
    df_monthly = df[df['Country'].isin(target_countries)].copy()
    df_monthly['year_month'] = df_monthly['Date_reported'].dt.to_period('M')

    df_monthly_agg = df_monthly.groupby(['Country', 'year_month']).agg({
        'Cumulative_cases': 'max',
        'New_cases': 'sum',
        'Cumulative_deaths': 'max'
    }).reset_index()

    df_monthly_agg['year_month'] = df_monthly_agg['year_month'].dt.to_timestamp()

    return df_monthly_agg


# ============================================================================
# 2. 변곡점 데이터 정의
# ============================================================================

def get_inflection_points():
    """
    각 국가별 주요 변곡점(변이 바이러스, 대유행 시점) 정의

    Returns:
    --------
    inflection_data : dict
        국가별 변곡점 정보 딕셔너리
    """
    inflection_data = {
        'China': [
            {'date': '2020-02-01', 'reason': 'Wuhan outbreak peak'},
            {'date': '2022-03-01', 'reason': 'Omicron surge with lockdowns'}
        ],
        'United States of America': [
            {'date': '2020-04-01', 'reason': 'First wave nationwide spread'},
            {'date': '2020-12-01', 'reason': 'Winter surge (Alpha variant)'},
            {'date': '2021-08-01', 'reason': 'Delta variant wave'},
            {'date': '2022-01-01', 'reason': 'Omicron surge peak'}
        ],
        'Italy': [
            {'date': '2020-03-01', 'reason': 'Europe first major outbreak'},
            {'date': '2020-10-01', 'reason': 'Second wave'},
            {'date': '2021-11-01', 'reason': 'Delta variant surge'}
        ],
        'Republic of Korea': [
            {'date': '2020-02-01', 'reason': 'Daegu Shincheonji cluster'},
            {'date': '2021-12-01', 'reason': 'Omicron breakthrough'},
            {'date': '2022-03-01', 'reason': 'Omicron peak'}
        ],
        'India': [
            {'date': '2021-05-01', 'reason': 'Delta variant catastrophic surge'},
            {'date': '2022-01-01', 'reason': 'Omicron wave'}
        ],
        'Brazil': [
            {'date': '2021-03-01', 'reason': 'Gamma variant surge'},
            {'date': '2022-01-01', 'reason': 'Omicron wave'}
        ]
    }

    return inflection_data


# ============================================================================
# 3. 색상 팔레트 정의
# ============================================================================

def get_color_palette():
    """
    국가별 색상 팔레트 반환

    Returns:
    --------
    color_palette : dict
        국가별 색상 코드
    """
    color_palette = {
        'China': '#E74C3C',                      # Red
        'United States of America': '#3498DB',   # Blue
        'Italy': '#2ECC71',                      # Green
        'Republic of Korea': '#9B59B6',          # Purple
        'India': '#F39C12',                      # Orange
        'Brazil': '#1ABC9C'                      # Teal
    }

    return color_palette


# ============================================================================
# 4. Plotly 인터랙티브 그래프 생성
# ============================================================================

def create_interactive_chart(df_monthly, inflection_data, color_palette, 
                            viz_countries=None, output_file='covid19_inflection_points.html'):
    """
    Plotly 인터랙티브 그래프 생성 및 HTML 저장

    Parameters:
    -----------
    df_monthly : pd.DataFrame
        월별 집계 데이터
    inflection_data : dict
        변곡점 정보
    color_palette : dict
        색상 팔레트
    viz_countries : list
        시각화할 국가 리스트 (None이면 color_palette의 국가 사용)
    output_file : str
        출력 HTML 파일명

    Returns:
    --------
    fig : plotly.graph_objects.Figure
        생성된 Plotly Figure 객체
    """

    if viz_countries is None:
        viz_countries = list(color_palette.keys())

    # Figure 생성
    fig = go.Figure()

    # 각 국가별 라인 플롯 추가
    for country in viz_countries:
        df_country = df_monthly[df_monthly['Country'] == country].sort_values('year_month')

        fig.add_trace(go.Scatter(
            x=df_country['year_month'],
            y=df_country['Cumulative_cases'],
            mode='lines',
            name=country,
            line=dict(width=3, color=color_palette.get(country)),
            hovertemplate='<b>%{fullData.name}</b><br>' +
                          'Date: %{x|%Y-%m}<br>' +
                          'Cumulative Cases: %{y:,.0f}<br>' +
                          '<extra></extra>'
        ))

        # 변곡점 마커 추가
        if country in inflection_data:
            inflection_dates = []
            inflection_cases = []
            inflection_texts = []
            inflection_hovers = []

            for point in inflection_data[country]:
                point_date = pd.to_datetime(point['date'])
                df_point = df_country[df_country['year_month'] == point_date]

                if not df_point.empty:
                    inflection_dates.append(point_date)
                    inflection_cases.append(df_point['Cumulative_cases'].values[0])
                    inflection_texts.append(point['reason'])
                    inflection_hovers.append(
                        f"<b>{country}</b><br>" +
                        f"<b>{point['reason']}</b><br>" +
                        f"Date: {point_date.strftime('%Y-%m')}<br>" +
                        f"Cases: {df_point['Cumulative_cases'].values[0]:,.0f}"
                    )

            if inflection_dates:
                fig.add_trace(go.Scatter(
                    x=inflection_dates,
                    y=inflection_cases,
                    mode='markers+text',
                    marker=dict(
                        size=12,
                        symbol='diamond',
                        color=color_palette.get(country),
                        line=dict(width=2, color='white')
                    ),
                    text=inflection_texts,
                    textposition='top center',
                    textfont=dict(size=10, color='#2C3E50'),
                    showlegend=False,
                    hovertemplate='%{hovertext}<extra></extra>',
                    hovertext=inflection_hovers
                ))

    # 레이아웃 설정
    fig.update_layout(
        title={
            'text': "<b>COVID-19 Cumulative Cases by Country with Key Inflection Points (2020-2023)</b><br>" +
                    "<span style='font-size: 14px; color: #7F8C8D;'>Source: WHO Global Data | Diamond markers indicate major outbreak events and variant waves</span>",
            'x': 0.5,
            'xanchor': 'center',
            'font': {'size': 20, 'color': '#2C3E50'}
        },
        xaxis_title="<b>Date</b>",
        yaxis_title="<b>Cumulative Confirmed Cases</b>",
        hovermode='closest',
        template='plotly_white',
        legend=dict(
            title={'text': '<b>Country</b>', 'font': {'size': 14}},
            orientation='v',
            yanchor='top',
            y=0.98,
            xanchor='right',
            x=0.98,
            bgcolor='rgba(255, 255, 255, 0.8)',
            bordercolor='#BDC3C7',
            borderwidth=1,
            font={'size': 12}
        ),
        plot_bgcolor='#F8F9FA',
        paper_bgcolor='white',
        font={'family': 'Arial, sans-serif', 'color': '#2C3E50'},
        height=700,
        margin=dict(l=80, r=80, t=120, b=80)
    )

    # X축 설정
    fig.update_xaxes(
        tickformat='%Y-%m',
        dtick="M3",  # 3개월 간격
        gridcolor='#E5E7E9',
        showline=True,
        linewidth=2,
        linecolor='#BDC3C7',
        mirror=True,
        tickfont={'size': 11}
    )

    # Y축 설정
    fig.update_yaxes(
        tickformat=',',
        separatethousands=True,
        gridcolor='#E5E7E9',
        showline=True,
        linewidth=2,
        linecolor='#BDC3C7',
        mirror=True,
        tickfont={'size': 11}
    )

    # HTML 파일로 저장
    fig.write_html(
        output_file,
        config={
            'displayModeBar': True,
            'displaylogo': False,
            'modeBarButtonsToRemove': ['pan2d', 'lasso2d', 'select2d'],
            'toImageButtonOptions': {
                'format': 'png',
                'filename': 'covid19_country_inflection_points',
                'height': 700,
                'width': 1200,
                'scale': 2
            }
        }
    )

    return fig


# ============================================================================
# 5. 통계 정보 출력
# ============================================================================

def print_statistics(df_monthly, inflection_data, viz_countries):
    """
    데이터 통계 정보 출력

    Parameters:
    -----------
    df_monthly : pd.DataFrame
        월별 집계 데이터
    inflection_data : dict
        변곡점 정보
    viz_countries : list
        시각화 국가 리스트
    """
    print("=" * 80)
    print("COVID-19 국가별 변곡점 분석 리포트")
    print("=" * 80)

    print("\n📊 포함된 국가 및 변곡점:")
    for country in viz_countries:
        count = len(inflection_data.get(country, []))
        max_cases = df_monthly[df_monthly['Country'] == country]['Cumulative_cases'].max()
        print(f"  • {country:30s}: {count}개 변곡점 | 최대 누적확진자: {max_cases:,.0f}")

    print("\n💡 인터랙티브 기능:")
    print("  ✓ 마우스 호버: 상세 데이터 확인")
    print("  ✓ 범례 클릭: 국가별 표시/숨김 토글")
    print("  ✓ 드래그: 특정 기간 줌 인")
    print("  ✓ 더블클릭: 줌 리셋")
    print("  ✓ 카메라 아이콘: PNG 이미지 다운로드")

    print("\n🔍 주요 변곡점 상세:")
    for country in viz_countries:
        if country in inflection_data:
            print(f"\n  [{country}]")
            for point in inflection_data[country]:
                print(f"    - {point['date']}: {point['reason']}")


# ============================================================================
# 6. 메인 실행 함수
# ============================================================================

def main():
    """
    메인 실행 함수
    """
    # 데이터 로드 및 전처리
    print("데이터 로드 중...")
    df_monthly = load_and_preprocess_data('WHO-COVID-19-global-daily-data.csv')

    # 변곡점 데이터 로드
    inflection_data = get_inflection_points()

    # 색상 팔레트 로드
    color_palette = get_color_palette()

    # 시각화할 국가 리스트
    viz_countries = list(color_palette.keys())

    # 그래프 생성
    print("인터랙티브 그래프 생성 중...")
    fig = create_interactive_chart(
        df_monthly=df_monthly,
        inflection_data=inflection_data,
        color_palette=color_palette,
        viz_countries=viz_countries,
        output_file='covid19_inflection_points_interactive.html'
    )

    # 통계 정보 출력
    print_statistics(df_monthly, inflection_data, viz_countries)

    print("\n" + "=" * 80)
    print("✅ 완료! HTML 파일이 생성되었습니다: covid19_inflection_points_interactive.html")
    print("=" * 80)


# ============================================================================
# 실행
# ============================================================================

if __name__ == "__main__":
    main()
